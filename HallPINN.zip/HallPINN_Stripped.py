"""
Title: Code to run Ion Continuity (ICE), Ion Momentum (IME), Electron Energy (EEE),
Electron Momentum (EME), and Neutral Continuity (NCE) equations for a one-dimensional
Hall Thruster via the use of Physics-Informed Neural Networks(PINNs) IN PYTORCH
Co-Authors: Sarah Burrows, Dr. Christopher McDevitt

This code intends to construct a neural network to successfully replicate the reduced physics
incorporated as described in LaFleur/Petronio

INPUTS:
    z: axial position along the hall thruster
OUTPUTS:
    optimized ion velocity (Vi)
    optimized ion number density (ni)
    electron temperature (Te)
    electron energy (Ez)
    optimized neutral density (nn)

Neural Network Architecture:
    Fully-Connected Neural Network
    Dirichlet Boundary Conditions applied via an output transform
    Glorot Uniform Initializer
    Hyperbolic tangent activation function

Modes (set IF_TRAIN below):
    IF_TRAIN = True  : train the published recipe (1,500 SOAP epochs + 25,000
                       SSBroyden iterations), writing checkpoints and loss logs.
    IF_TRAIN = False : load a trained checkpoint and regenerate every figure,
                       benchmark statistic, the constant-voltage sweep, the
                       operating-envelope map, the extrapolation test and the
                       cross-validation against hall_fluid_reference.py.
Data: PetronioData/ (digitized benchmark curves and rate_coefficients.xlsx)
      is expected next to this file.
"""

import torch #type: ignore
import torch.nn as nn #type: ignore
import numpy as np #type: ignore
import time
import copy
import sys
import os
import shutil
import pytorch_optimizer #type: ignore
from datetime import datetime
import math

torch.set_default_dtype(torch.float64)

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR   = os.path.join(SCRIPT_DIR, 'PetronioData')   # digitized benchmark + rate table

SEED = 42
torch.manual_seed(SEED)
np.random.seed(SEED)
torch.cuda.manual_seed_all(SEED)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False


# ==============================================================================
# SECTION A: Tabulated Rate Coefficient Interpolation (Xenon, from rate_coefficients.xlsx)
# ==============================================================================
# Column layout (from rate_coefficients.xlsx):
#   Col 0:  T_e (eV)
#   Col 1:  K_iz_Xe (m^3/s)   <-- ionization rate coefficient
#   Col 2:  K_m_Xe (m^3/s)    <-- momentum transfer rate coefficient
#   Col 3:  varepsilon_c_Xe (eV) <-- average collisional energy cost per ion pair
#

import numpy as np #type: ignore
import torch #type: ignore



# --- Load table ---
try:
    import pandas as pd #type: ignore
    _df = pd.read_excel(os.path.join(DATA_DIR, "rate_coefficients.xlsx"))
    _table = _df.values.astype(float)
except Exception as _e:
    raise RuntimeError(f"Could not load rate_coefficients.xlsx: {_e}")

# Column layout:
#   Col 0: T_e (eV)
#   Col 1: K_iz_Xe (m^3/s)  -- physical, scientific notation
#   Col 2: K_m_Xe  (m^3/s)  -- physical, scientific notation
#   Col 3: varepsilon_c_Xe (eV)

_Te_table    = _table[:, 1]   # eV
_Kiz_table   = _table[:, 2]   # m^3/s  (already physical)
_Km_table    = _table[:, 3]   # m^3/s  (already physical)
_epsc_table  = _table[:, 4]   # eV

# --- Characteristic values at Te = epsilon_iz = 12.13 eV Table 7 ---
epsilon_iz_Xe = 12.13    # eV
Kstar_iz_Xe   = 5.45e-14 # m^3/s  (used only for normalization in residuals)
Kstar_m_Xe    = 2.37e-13 # m^3/s

# Quick sanity check: interpolate at 12.13 eV and compare to Table 7
_idx_ref     = int(np.argmin(np.abs(_Te_table - epsilon_iz_Xe)))
_Kiz_at_ref  = _Kiz_table[_idx_ref]
_Km_at_ref   = _Km_table[_idx_ref]
_epsc_at_ref = _epsc_table[_idx_ref]
print(f"[Table check] At Te={_Te_table[_idx_ref]:.2f} eV: "
      f"K_iz={_Kiz_at_ref:.3e} m^3/s (expect ~5.45e-14), "
      f"K_m={_Km_at_ref:.3e} m^3/s (expect ~2.37e-13), "
      f"eps_c={_epsc_at_ref:.3e} eV (expect ~20.52), ")

# --- Build log-linear interpolants over rows where both K > 0 ---
_valid       = (_Kiz_table > 0) & (_Km_table > 0) & (_Te_table > 0)
_Te_valid    = _Te_table[_valid]
_logKiz_valid = np.log(_Kiz_table[_valid])
_logKm_valid  = np.log(_Km_table[_valid])
_epsc_valid  = _epsc_table[_valid]


# ==============================================================================
# SECTION B: PyTorch-differentiable wrappers for use inside the PINN
# ==============================================================================
# These wrappers call numpy interpolation via a non-differentiable path,
# which is appropriate for residual evaluation (not for backprop through
# the rate coefficients themselves, which is consistent with the fluid model
# approach in where Te is solved self-consistently at each point).
# --- PyTorch lookup tables (moved to GPU once at startup) ---

_Te_torch     = torch.tensor(_Te_valid,    dtype=torch.float64)
_logKiz_torch = torch.tensor(_logKiz_valid, dtype=torch.float64)
_logKm_torch  = torch.tensor(_logKm_valid,  dtype=torch.float64)
_epsc_torch   = torch.tensor(_epsc_valid,  dtype=torch.float64)


def _torch_monotone_cubic_interp(x, xp, fp):
    """
    Fritsch-Carlson monotone cubic Hermite interpolation — fully vectorized.
    Guarantees C1 continuity at all knots with no Python loops.
    """
    # Tables are already on the correct device — skip .to() if called hot
    n = len(xp)

    # Step 1: secant slopes
    h     = xp[1:] - xp[:-1]           # (n-1,)
    delta = (fp[1:] - fp[:-1]) / h     # (n-1,)

    # Step 2: initialize tangents
    m = torch.empty(n, dtype=fp.dtype, device=fp.device)
    m[1:-1] = 0.5 * (delta[:-1] + delta[1:])
    m[0]    = delta[0]
    m[-1]   = delta[-1]

    # Step 3: Fritsch-Carlson monotonicity — fully vectorized, no Python loop
    with torch.no_grad():
        # Compute alpha, beta, r for all intervals at once
        safe_delta = delta + 1e-300
        alpha = m[:-1] / safe_delta      # (n-1,)
        beta  = m[1:]  / safe_delta      # (n-1,)
        r     = alpha**2 + beta**2       # (n-1,)

        # Where delta ~ 0: force m to zero at both endpoints of interval
        flat = delta.abs() < 1e-300
        m[:-1] = torch.where(flat, torch.zeros_like(m[:-1]), m[:-1])
        m[1:]  = torch.where(flat, torch.zeros_like(m[1:]),  m[1:])

        # Where r > 9: rescale both tangents
        needs_rescale = r > 9.0
        tau = torch.where(needs_rescale, 3.0 / torch.sqrt(r.clamp(min=1e-30)),
                          torch.ones_like(r))
        m[:-1] = torch.where(needs_rescale, tau * alpha * delta, m[:-1])
        m[1:]  = torch.where(needs_rescale, tau * beta  * delta, m[1:])

    # Step 4: evaluate Hermite basis (unchanged — already vectorized)
    idx = torch.searchsorted(xp.contiguous(), x.contiguous())
    idx = torch.clamp(idx, 1, n - 1)
    x0  = xp[idx - 1];  x1 = xp[idx]
    f0  = fp[idx - 1];  f1 = fp[idx]
    m0  = m[idx - 1];   m1 = m[idx]
    hk  = x1 - x0
    t   = torch.clamp((x - x0) / (hk + 1e-300), 0.0, 1.0)

    h00 =  2*t**3 - 3*t**2 + 1
    h10 =    t**3 - 2*t**2 + t
    h01 = -2*t**3 + 3*t**2
    h11 =    t**3 -   t**2

    return h00*f0 + h10*hk*m0 + h01*f1 + h11*hk*m1


def lookup_Kiz_torch(Te_eV):
    return torch.exp(_torch_monotone_cubic_interp(Te_eV, _Te_torch, _logKiz_torch))

def lookup_Km_torch(Te_eV):
    return torch.exp(_torch_monotone_cubic_interp(Te_eV, _Te_torch, _logKm_torch))

def lookup_epsc_torch(Te_eV):
    return _torch_monotone_cubic_interp(Te_eV, _Te_torch, _epsc_torch)



# ==============================================================================
# SECTION C: Wall loss terms nu_iw, nu_ew, epsilon_w
# Following Lafleur & Chabert 2025, equations (9)-(14),
# and Petronio et al. 2026, equations (10)-(12).
# ==============================================================================
def compute_wall_losses(Te_bar: torch.Tensor,
                        ni_bar: torch.Tensor,
                        delta_r: float,
                        hR: float = 0.3) -> tuple:
    """
    Compute normalized wall collision frequencies and energy loss per event.

    Physics (Lafleur & Chabert 2025 eqs. 9-14; Petronio et al. 2026 eqs. 10-12):
      - Ion-wall collision frequency:
            nu_iw = 2 * hR * u_B / Delta_r,   u_B = sqrt(e*Te/m_i)
      - Electron-wall collision frequency:
            nu_ew = nu_iw / (1 - sigma)
      - Average electron energy lost at wall:
            epsilon_w = Te * {2 + (1-sigma)*ln[(1-sigma)*sqrt(M/(2*pi*me))]}
      - SEE coefficient (boron nitride):
            sigma_SEE = a*Te^b,  a=0.207 eV^-b, b=0.549
            sigma_SCL = 1 - 8.3*sqrt(m_e/m_i)   (space-charge limit)

    Space-charge limit:
      sigma = sigma_SEE. The SCL cap is applied ONLY as a hard floor on the
      nu_ew denominator (= min(sigma_SEE, sigma_SCL) for nu_ew), so nu_ew
      saturates at ~nu_iw/(1 - sigma_SCL) ~ 59*nu_iw when Te runs hot instead
      of diverging. eps_w uses the raw (1 - sigma_SEE). For the SPT-100 at
      250 V the crossover (Te ~ 17.1 eV) is above the converged peak, so the
      floor is inert and this equals Petronio's expression throughout.
      This is the version that converged to ~1e-11.

    Returns:
        nu_iw_bar, nu_ew_bar, eps_w_bar, sigma   (all dimensionless except sigma)
    """
    # --- Physical constants ---
    e_charge = 1.6022e-19   # C
    m_i      = 2.18e-25     # kg  (Xenon ion mass, as in your code)
    m_e      = 9.109e-31    # kg

    # --- Convert normalized Te to physical units ---
    Te_phys_eV = Te_bar * T_ref         # eV
    Te_phys_J  = Te_phys_eV * e_charge  # J

    # --- Bohm velocity (m/s):  u_B = sqrt(e*Te/m_i) ---
    Te_phys_J_safe = torch.clamp(Te_phys_J, min=1e-30)
    u_B = torch.sqrt(Te_phys_J_safe / m_i)

    # --- Ion-wall collision frequency (1/s):  nu_iw = 2*hR*u_B/Delta_r ---
    nu_iw_phys = 2.0 * hR * u_B / delta_r

    # --- SEE coefficient (boron nitride):  sigma_SEE = a*Te^b ---
    a_SEE, b_SEE = 0.207, 0.549
    Te_safe_eV = torch.clamp(Te_phys_eV, min=0.01)
    sigma_SEE  = a_SEE * (Te_safe_eV ** b_SEE)

    # sigma = min(sigma_SEE, sigma_SCL); inert at the solution -> sigma_SEE.
    sigma = sigma_SEE
    one_minus_sigma = 1.0 - sigma       # raw; used directly in eps_w

    # --- Electron-wall collision frequency (1/s):  nu_ew = nu_iw/(1-sigma) ---
    # Space-charge floor applied HERE ONLY, on the denominator.
    # (1 - sigma_SCL) ~ 0.017;  (1 - sigma)|solution ~ 0.029 > 0.017 -> inert.
    sigma_SCL = 1.0 - 8.3 * np.sqrt(m_e / m_i)          # ~0.983
    denom_ew  = torch.clamp(one_minus_sigma, min=(1.0 - sigma_SCL))
    nu_ew_phys = nu_iw_phys / denom_ew

    # --- Average electron energy lost at wall (eV) ---
    # Raw (1 - sigma), exactly as in the working version.
    M_over_2pi_me = m_i / (2.0 * np.pi * m_e)
    ln_arg      = one_minus_sigma * np.sqrt(M_over_2pi_me)
    ln_arg_safe = torch.clamp(ln_arg, min=1e-30)
    eps_w_eV    = Te_phys_eV * (2.0 + one_minus_sigma * torch.log(ln_arg_safe))

    # --- Normalize back to code units ---
    nu_iw_bar = nu_iw_phys / nu_ref
    nu_ew_bar = nu_ew_phys / nu_ref
    eps_w_bar = eps_w_eV   / T_ref

    return nu_iw_bar, nu_ew_bar, eps_w_bar, sigma

# =====================
# SSBroyden2 optimizer
# =====================

def _phi_and_derphi(eval_fg, xk, pk, alpha):
    x = xk + alpha * pk
    f, g = eval_fg(x)
    derphi = torch.dot(g, pk)
    return f, g, derphi


def _zoom(eval_fg, xk, pk, phi0, derphi0, c1, c2,
          alo, ahi, phi_alo, derphi_alo, maxiter=20):
    for _ in range(maxiter):
        aj = 0.5 * (alo + ahi)
        phi_aj, g_aj, derphi_aj = _phi_and_derphi(eval_fg, xk, pk, aj)
        bad = (not torch.isfinite(torch.as_tensor(phi_aj))) or \
              (not torch.isfinite(torch.as_tensor(derphi_aj)))
        if bad or (phi_aj > phi0 + c1 * aj * derphi0) or (phi_aj >= phi_alo):
            ahi = aj
        else:
            if abs(float(derphi_aj)) <= -c2 * float(derphi0):
                return aj, phi_aj, g_aj
            if float(derphi_aj) * (ahi - alo) >= 0:
                ahi = alo
            alo        = aj
            phi_alo    = phi_aj
            derphi_alo = derphi_aj
    phi_alo2, g_alo2, _ = _phi_and_derphi(eval_fg, xk, pk, alo)
    return alo, phi_alo2, g_alo2


def strong_wolfe_line_search(eval_fg, xk, pk, gfk, old_fval,
                              c1=1e-4, c2=0.9, amax=None,
                              maxiter=10, zoom_maxiter=20, alpha1=1.0):
    derphi0 = torch.dot(gfk, pk)
    if (not torch.isfinite(derphi0)) or float(derphi0) >= 0.0:
        pk      = -gfk
        derphi0 = -torch.dot(gfk, gfk)
    phi0      = old_fval
    alpha0    = 0.0
    alpha1    = float(alpha1)
    if amax is not None:
        alpha1 = min(alpha1, float(amax))
    phi_a0    = phi0
    derphi_a0 = derphi0
    phi_a1, g_a1, derphi_a1 = _phi_and_derphi(eval_fg, xk, pk, alpha1)
    for i in range(maxiter):
        # Non-finite trial (e.g. exp overflow at a large step) must be treated
        # as "step too far". NaN silently fails EVERY comparison below, which
        # would otherwise double alpha and eventually return the NaN point.
        bad = (not torch.isfinite(torch.as_tensor(phi_a1))) or \
              (not torch.isfinite(torch.as_tensor(derphi_a1)))
        if bad or (phi_a1 > phi0 + c1 * alpha1 * derphi0) or (i > 0 and phi_a1 >= phi_a0):
            a_star, phi_star, g_star = _zoom(
                eval_fg, xk, pk, phi0, derphi0, c1, c2,
                alpha0, alpha1, phi_a0, derphi_a0, maxiter=zoom_maxiter)
            return float(a_star), xk + a_star * pk, phi_star, g_star
        if abs(float(derphi_a1)) <= -c2 * float(derphi0):
            return float(alpha1), xk + alpha1 * pk, phi_a1, g_a1
        if float(derphi_a1) >= 0.0:
            a_star, phi_star, g_star = _zoom(
                eval_fg, xk, pk, phi0, derphi0, c1, c2,
                alpha1, alpha0, phi_a1, derphi_a1, maxiter=zoom_maxiter)
            return float(a_star), xk + a_star * pk, phi_star, g_star
        alpha0, phi_a0, derphi_a0 = alpha1, phi_a1, derphi_a1
        alpha1 = 2.0 * alpha1
        if amax is not None:
            alpha1 = min(alpha1, float(amax))
        phi_a1, g_a1, derphi_a1 = _phi_and_derphi(eval_fg, xk, pk, alpha1)
    return float(alpha1), xk + alpha1 * pk, phi_a1, g_a1


class SSBroyden2(torch.optim.Optimizer):
    """Self-scaled Broyden quasi-Newton method (Urban et al. 2025) with a
    strong-Wolfe line search and a DENSE inverse-Hessian approximation H
    (P x P, P = number of parameters).

    Self-scaling factor tau_k and Broyden-family parameter phi_k are
    recomputed every step (plain BFGS is the special case phi = 1, tau = 1).
    """
    def __init__(self, params, lr=1.0, gtol=1e-10, xrtol=0.0,
                 line_search="strong_wolfe", c1=1e-4, c2=0.9, backtrack=0.5,
                 ls_max_steps=25, wolfe_maxiter=10, zoom_maxiter=20,
                 amax=None, initial_scale=False, eps=1e-30,
                 dtype=torch.float64, device=None):
        super().__init__(params, defaults={})
        self.lr, self.gtol, self.xrtol = lr, gtol, xrtol
        self.line_search    = line_search
        self.c1, self.c2, self.backtrack = c1, c2, backtrack
        self.ls_max_steps   = ls_max_steps
        self.wolfe_maxiter  = wolfe_maxiter
        self.zoom_maxiter   = zoom_maxiter
        self.amax           = amax
        self.initial_scale  = initial_scale
        self.eps            = eps
        self.dtype          = dtype
        self._params        = list(self.param_groups[0]["params"])
        self.device         = device if device is not None else self._params[0].device
        self._numels        = [p.numel() for p in self._params]
        self._P             = int(sum(self._numels))
        self.state["H"]     = torch.eye(self._P, device=self.device, dtype=self.dtype)
        self.state["x"]     = self._gather_flat_params().detach().clone()
        self.state["k"]     = 0

    def _gather_flat_params(self):
        return torch.cat([p.detach().reshape(-1) for p in self._params])

    def _set_flat_params_(self, flat):
        with torch.no_grad():
            off = 0
            for p, n in zip(self._params, self._numels):
                p.copy_(flat[off:off + n].view_as(p))
                off += n

    def _gather_flat_grad(self):
        flats = []
        for p in self._params:
            if p.grad is None:
                flats.append(torch.zeros(p.numel(), device=self.device, dtype=self.dtype))
            else:
                flats.append(p.grad.detach().reshape(-1))
        return torch.cat(flats)

    def _eval_loss_and_grad(self, closure):
        loss = closure()
        if not torch.is_tensor(loss):
            loss = torch.tensor(loss, device=self.device, dtype=self.dtype)
        return loss.detach(), self._gather_flat_grad()

    def step(self, closure):
        self.zero_grad(set_to_none=True)
        fk, gk = self._eval_loss_and_grad(closure)
        xk, Hk, N = self._gather_flat_params().detach(), self.state["H"], self._P
        gnorm = torch.linalg.vector_norm(gk).item()
        if gnorm <= self.gtol:
            return fk
        pk = -(Hk @ gk)

        def eval_fg_at(x_flat):
            self._set_flat_params_(x_flat)
            self.zero_grad(set_to_none=True)
            return self._eval_loss_and_grad(closure)

        alpha, xkp1, fkp1, gkp1 = strong_wolfe_line_search(
            eval_fg=eval_fg_at, xk=xk, pk=pk, gfk=gk, old_fval=fk,
            c1=self.c1, c2=self.c2, amax=self.amax,
            maxiter=self.wolfe_maxiter, zoom_maxiter=self.zoom_maxiter,
            alpha1=float(self.lr))
        self._set_flat_params_(xkp1)

        sk  = xkp1 - xk
        yk  = gkp1 - gk
        ys  = torch.dot(yk, sk).item()
        if abs(ys) < self.eps:
            self.state["x"] = xkp1.detach().clone()
            self.state["k"] += 1
            return fkp1

        rhok    = 1.0 / ys
        Hkyk    = Hk @ yk
        ykHkyk  = torch.dot(yk, Hkyk).item()
        if abs(ykHkyk) < self.eps:
            self.state["x"] = xkp1.detach().clone()
            self.state["k"] += 1
            return fkp1

        hk     = ykHkyk * rhok
        bk     = -alpha * rhok * torch.dot(sk, gk).item()
        ak     = bk * hk - 1.0
        denom  = 1.0 + ak
        denom  = denom if abs(denom) > self.eps else (self.eps if denom >= 0 else -self.eps)
        rad    = max(abs(ak) / denom, 0.0)
        rhokm  = min(1.0, hk * (1.0 - math.sqrt(rad)))
        thetakm = 0.0 if abs(ak) < self.eps else (rhokm - 1.0) / ak
        thetakp = (1.0 / rhokm) if abs(rhokm) > self.eps else (1.0 / self.eps)
        inner   = thetakp if abs(bk) < self.eps else (1.0 - bk) / bk
        thetak  = max(thetakm, min(thetakp, inner))
        rhokk   = min(1.0, (1.0 / bk) if abs(bk) > self.eps else (1.0 / self.eps))
        sigmak  = 1.0 + thetak * ak
        exp_    = 1.0 / (1.0 - float(N))
        sigmaknm1 = abs(sigmak) ** exp_ if abs(sigmak) > 0 else 0.0
        if thetak <= 0.0:
            tauk = min(rhokk * sigmaknm1, sigmak)
        else:
            tauk = rhokk * min(sigmaknm1, 1.0 / thetak)
        vk     = (sk * rhok) - (Hkyk / ykHkyk)
        denom3 = 1.0 + ak * thetak
        denom3 = denom3 if abs(denom3) > self.eps else (self.eps if denom3 >= 0 else -self.eps)
        phik   = (1.0 - thetak) / denom3
        tauk   = tauk if abs(tauk) > self.eps else (self.eps if tauk >= 0 else -self.eps)

        H_term = (Hk
                  - torch.outer(Hkyk, Hkyk) / ykHkyk
                  + (phik * ykHkyk) * torch.outer(vk, vk))
        self.state["H"] = H_term / tauk + rhok * torch.outer(sk, sk)
        self.state["x"] = xkp1.detach().clone()
        self.state["k"] += 1
        return fkp1

# ==============================================================================
# FILE MANAGEMENT
# ==============================================================================

if os.path.exists("plots") and os.path.isdir("plots"):
    print("Detected existing 'plots' directory. Running in Cluster Mode.")
    base_path  = "."
    plot_path  = "plots/"
    model_path = "checkpoints/"
else:
    print("No local 'plots' directory found. Running in Local/Debug Mode.")
    if len(sys.argv) > 1:
        date_time_str = sys.argv[1]
    else:
        date_time_str = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    base_path  = f"models/{date_time_str}"
    plot_path  = f"{base_path}/plots/"
    model_path = f"{base_path}/"
    os.makedirs(plot_path, exist_ok=True)

print(f"Output plots  -> {plot_path}")
print(f"Output models -> {model_path}")


def save_losses_to_dat(epoch_list, total_loss_list, out_path):
    data = np.column_stack((epoch_list, total_loss_list))
    np.savetxt(out_path, data, delimiter=',', header='Epoch,Loss', comments='')


def load_losses_from_dat(path):
    try:
        data = np.loadtxt(path, delimiter=',', skiprows=1)
        if data.ndim == 1:
            return [data[0]], [data[1]]
        return data[:, 0].tolist(), data[:, 1].tolist()
    except Exception as e:
        print(f"Warning: Could not load losses from {path}. Error: {e}")
        return [], []


# ==============================================================================
# RAW (unweighted) per-equation loss logging
# ------------------------------------------------------------------------------
# Raw mean-square residuals mean((r_i)^2) are the weighting-independent
# currency for comparing runs: they answer "how well is each PDE satisfied?"
# regardless of whether the weights were hand-tuned c^2 values or learned by
# GradNorm. Weighted totals from runs with different weights are NOT
# comparable (the weights are different measurement units).
# ==============================================================================

RAW_EQ_NAMES = ['ice', 'ime', 'eme', 'eee', 'nce']

raw_loss_history = {'step': [], 'phase': [], 'wall_s': []}   # phase: 0 = SOAP, 1 = SSBroyden
TRAIN_T0 = None   # set when training starts; wall_s is measured from it
for _eq in RAW_EQ_NAMES:
    raw_loss_history[f'train_{_eq}'] = []
    raw_loss_history[f'test_{_eq}']  = []


def log_raw_losses(step, phase, train_vals, test_vals):
    """train_vals / test_vals: dicts of RAW mean-square losses per equation."""
    raw_loss_history['step'].append(step)
    raw_loss_history['phase'].append(phase)
    raw_loss_history['wall_s'].append(time.time() - TRAIN_T0 if TRAIN_T0 else float('nan'))
    for eq in RAW_EQ_NAMES:
        raw_loss_history[f'train_{eq}'].append(train_vals[eq])
        raw_loss_history[f'test_{eq}'].append(test_vals[eq])


def save_raw_losses_dat(out_path):
    cols   = ['step', 'phase', 'wall_s'] + \
             [f'train_{eq}' for eq in RAW_EQ_NAMES] + \
             [f'test_{eq}'  for eq in RAW_EQ_NAMES]
    data   = np.column_stack([raw_loss_history[c] for c in cols])
    np.savetxt(out_path, data, delimiter=',',
               header=','.join(cols), comments='')


# ==============================================================================
# USER CONFIGURATION
# ------------------------------------------------------------------------------
# All user-set parameters live here. Nothing below this section should need
# editing for routine runs.
# ==============================================================================

# --- Run mode ---
IF_TRAIN   = False    # True : train as normal (SOAP + SSBroyden, checkpoints written).
                     # False: EVALUATION-ONLY. Load the published weights from
                     #        EVAL_DIR, run zero optimizer steps, write NO
                     #        checkpoint/loss files (protects the archived run),
                     #        and regenerate every plot + benchmark statistic.
EVAL_DIR   = os.path.join(SCRIPT_DIR, "models/1D_steady/2026-07-14-22:40:21/checkpoints")
EVAL_MODEL = "pinn_weights_final_ssbroyden.pth"

# --- Checkpoint loading (weights only) ---
LoadModel    = False          # True: warm-start from DataDir/ModelToLoad
DataDir      = EVAL_DIR
ModelToLoad  = EVAL_MODEL
TrainLossToLoad = "training_losses.dat"
SaveEveryEpoch  = 5000
# SSBroyden iterations at which an extra checkpoint is written (convergence study)
SSB_CHECKPOINT_ITERS = (100, 300, 500, 1000, 2000, 3000, 5000, 7500, 10000, 15000, 20000)

# --- Feature toggles ---
USE_SSBROYDEN = True     # second (quasi-Newton) phase
USE_GRADNORM  = True     # adaptive loss weights during the SOAP phase

# --- Training schedule ---
epochsSOAP  = 1500      # first-order (SOAP) epochs
epochsSSB   = 25_000    # self-scaled Broyden iterations
lr          = 2.5e-4    # SOAP learning rate

# --- Collocation points ---
NUM_TRAIN_POINTS = 65_536        # scrambled-Sobol training points; powers of
                                 # 2 give Sobol its optimal discrepancy
SOBOL_SEED       = 0             # scramble seed for reproducible point sets
num_test_points  = 200_000       # random (z,Qm,R) test triples

# --- GradNorm ---
GRADNORM_ALPHA         = 1.5
GRADNORM_LR            = 0.025  # independent hyperparameter; the paper does
                                # not tie the weight LR to the network LR
GRADNORM_WARMUP_EPOCHS = 100    # hold w_i = 1 and defer L(0) caching until
                                # initialization transients wash out

# --- Evaluation-only overrides (IF_TRAIN = False) ---
# Weights are loaded, no optimizer step runs, and no checkpoint/loss file
# is written, so an evaluation launched inside an archived run directory
# cannot overwrite its training record.
if not IF_TRAIN:
    print("[CONFIG] EVALUATION-ONLY MODE: loading published model; no training.")
    LoadModel       = True
    epochsSOAP      = 0             # SOAP loop: range(start_epoch, 0) is empty
    USE_SSBROYDEN   = False         # skip SSB phase entirely
    num_test_points = 5_000         # the test set is only sampled in eval mode

print(f"--- CONFIGURATION ---")
print(f"Mode:            {'train' if IF_TRAIN else 'evaluate ' + os.path.join(DataDir, ModelToLoad)}")
print(f"Schedule:        SOAP {epochsSOAP} epochs (lr {lr:.1e}) + SSBroyden {epochsSSB} iters")
print(f"Collocation:     {NUM_TRAIN_POINTS} Sobol training points, {num_test_points} test points")
print(f"GradNorm:        {USE_GRADNORM} | seed {SEED}")
print(f"---------------------")

# ==============================================================================
# PHYSICAL / NORMALIZATION CONSTANTS  (Petronio Table III)
# ==============================================================================

def to_joules(eV):
    return eV * 1.6022e-19

device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {device}")

# --- Pin lookup tables to training device (do this once, here) ---
_Te_torch     = _Te_torch.to(device)
_logKiz_torch = _logKiz_torch.to(device)
_logKm_torch  = _logKm_torch.to(device)
_epsc_torch   = _epsc_torch.to(device)

r1 = 0.035
r2 = 0.050
A  = np.pi * (r2**2 - r1**2)
Va_phys = 250.0
Qm_phys = 5.0e-6
Id      = 4.5
Jt0     = Id / A
hR      = 0.3

m_i       = 2.18e-25
m_n       = m_i
m_e       = 9.1e-31
e         = 1.6022e-19
#epsilon_0 = 8.8542e-12
Bmax      = 200.0

T_ref     = 12.1
V_ref     = np.sqrt(to_joules(T_ref) / m_i)
Gamma_ref = 1e23
sigma_i0  = 3.6e-20
sigma_ref = sigma_i0 * np.sqrt(m_i / m_e)
n_ref     = Gamma_ref / V_ref
z_ref     = 1 / (n_ref * sigma_ref)
nu_ref    = sigma_ref * Gamma_ref

L      = 0.025 / z_ref
beta_B = 4.0
zMax   = L
zMin   = 0

Tg_K       = 705
kB_SI      = 1.380649e-23
Vn_phys    = np.sqrt(kB_SI * Tg_K / m_i)
Vn_bar_init = Vn_phys / V_ref


#Ezi      = 12.13
NormFlux = 0.0038   # Sets boundary condition on inlet density
#niInlet  = 0.005
ViInlet = Vn_phys / V_ref # ions assumed to enter at same speed as neutral gas
niInlet  = (Jt0/(e*n_ref)) / Vn_phys * NormFlux # computed from page 4 of Petronio et al. 2026
#niInlet  = 1e17/n_ref
#Tn_bar   = (Tg_K * 8.617e-5) / T_ref
#alpha_en = 2.5

nn0        = Qm_phys / (m_i * A * Vn_phys) - niInlet*n_ref
nn0_bar    = nn0 / n_ref
mdot     = Vn_bar_init * nn0_bar + niInlet * ViInlet

# --- Parametric operating-point ranges ---
Qm_min, Qm_max = 3.0e-6, 6.0e-6     # mass flow rate [kg/s]  (unchanged)
R_min,  R_max  = 1.0, 1.5            # Id / I_ion,max   (replaces Id_min, Id_max = 1.0, 7.0)

def operating_point(X):
    Qm_norm = X[:, 1:2]
    r_norm  = X[:, 2:3]                              # 3rd input now = current-fraction
    Qm_phys_vec = Qm_min + (Qm_max - Qm_min) * Qm_norm
    Iion_vec    = e * Qm_phys_vec / m_i              # full single-ionization current [A]
    Id_vec      = (R_min + (R_max - R_min) * r_norm) * Iion_vec
    Jt0_vec     = Id_vec / A
    niInlet_vec = (Jt0_vec / (e * n_ref)) / Vn_phys * NormFlux
    nn0_bar_vec = Qm_phys_vec / (m_i * A * Vn_phys * n_ref) - niInlet_vec
    mdot_vec    = Vn_bar_init * nn0_bar_vec + niInlet_vec * ViInlet
    return Qm_phys_vec, Id_vec, Jt0_vec, niInlet_vec, nn0_bar_vec, mdot_vec

print(f"=== Petronio SPT-100 operating point ===")
print(f"  Geometry:      A = {A*1e4:.2f} cm²,  Lch = {L*100:.2f} cm")
print(f"  Discharge:     Va = {Va_phys:.0f} V,  Id = {Id:.1f} A")
print(f"  Neutral inj:   Tg = {Tg_K:.0f} K  →  Vn = {Vn_phys:.1f} m/s")
print(f"                 nn0 = {nn0:.3e} m⁻³  →  Qm = {Qm_phys*1e6:.2f} mg/s")
print(f"  Normalization: n_ref = {n_ref:.3e},  V_ref = {V_ref:.1f}")
print(f"                 z_ref = {z_ref*1e3:.3f} mm,  L_norm = {L:.2f}")
print(f"                 mdot_bar = {mdot:.4e}")

Qm_check = m_i * A * mdot * n_ref * V_ref
print(f"  ✓ Round-trip check: Qm = {Qm_check*1e6:.3f} mg/s (should be {Qm_phys*1e6:.2f})")
print(f"========================================")

print(f"niInlet = {niInlet*n_ref}")

# ==============================================================================
# GradNorm balancer
# ==============================================================================

class GradNormBalancer:
    def __init__(self, model, loss_names, alpha=1.5, learning_rate=0.025,
                 warmup=100):
        self.model      = model
        self.loss_names = loss_names
        self.alpha      = alpha
        self.warmup     = warmup
        self.n_tasks    = len(loss_names)
        self.weights    = {
            name: torch.tensor(1.0, device=device, dtype=torch.float64, requires_grad=True)
            for name in loss_names
        }
        self.optimizer      = torch.optim.Adam(self.weights.values(), lr=learning_rate)
        self.initial_losses = {}
        self.shared_layer   = model.net[-3]
        print(f"GradNorm: Identified shared layer W: {self.shared_layer}")

    def step(self, losses_dict, global_step=0):
        # Warm-up: hold all weights at their current values (1.0 from init)
        # and do NOT cache L(0) yet. Epoch-0 losses contain initialization
        # transients (e.g. EEE ~ 2.7e5 from the unanchored Te = exp(raw)
        # transform); caching them poisons the loss ratios r_i = L(t)/L(0)
        # and drives the affected task to the clamp floor. Chen et al. (2018)
        # note L(0) should be a meaningful initial loss when training is
        # unstable early.
        if global_step < self.warmup:
            return {k: v.detach() for k, v in self.weights.items()}

        if global_step == self.warmup or not self.initial_losses:
            for name, loss in losses_dict.items():
                val = loss.item()
                # Floor is a divide-by-zero guard ONLY. It must sit far below
                # any converged loss value: with the old floor of 1e-5, a
                # post-resample re-cache of an equation already at ~1e-8
                # (e.g. ICE) pinned L(0) at 1e-5, so its ratio restarted at
                # ~1e-3 instead of ~1 and GradNorm suppressed it as "already
                # trained" (observed: ime handed to SSBroyden at w=0.027).
                self.initial_losses[name] = max(val, 1e-30)

        norms = []
        for name in self.loss_names:
            w_i = self.weights[name]
            L_i = losses_dict[name]
            weighted_loss = w_i * L_i
            grad = torch.autograd.grad(
                weighted_loss, self.shared_layer.weight,
                retain_graph=True, create_graph=True)[0]
            norms.append(torch.norm(grad, 2))

        norms_stack = torch.stack(norms)
        avg_norm    = torch.mean(norms_stack).detach()

        loss_ratios = []
        for name in self.loss_names:
            ratio = losses_dict[name].item() / self.initial_losses[name]
            loss_ratios.append(ratio)
        loss_ratios    = torch.tensor(loss_ratios, device=device)
        avg_loss_ratio = torch.mean(loss_ratios)
        relative_rates = loss_ratios / avg_loss_ratio

        l_grad = 0.0
        for i, name in enumerate(self.loss_names):
            target = avg_norm * (relative_rates[i] ** self.alpha)
            l_grad += torch.abs(norms_stack[i] - target)

        # Per Chen et al. (2018) Algorithm 1, L_grad is differentiated ONLY
        # w.r.t. the task weights w_i. Using .backward() here would also
        # deposit second-order gradients into every model parameter's .grad,
        # corrupting the subsequent SOAP step.
        w_list = [self.weights[name] for name in self.loss_names]
        gw = torch.autograd.grad(l_grad, w_list, retain_graph=True)
        self.optimizer.zero_grad()
        for w, g in zip(w_list, gw):
            w.grad = g
        self.optimizer.step()

        with torch.no_grad():
            for name in self.weights:
                self.weights[name].clamp_(min=0.01)
            total_weight   = sum(self.weights.values())
            normalize_coeff = self.n_tasks / total_weight
            for name in self.weights:
                self.weights[name] *= normalize_coeff

        return {k: v.detach() for k, v in self.weights.items()}

# ==============================================================================
# Neural network
# ==============================================================================

class PINN(nn.Module):
    def __init__(self, layer_sizes):
        super(PINN, self).__init__()
        layers = []
        for i in range(len(layer_sizes) - 2):
            layers.append(nn.Linear(layer_sizes[i], layer_sizes[i + 1]))
            layers.append(nn.Tanh())
        layers.append(nn.Linear(layer_sizes[-2], layer_sizes[-1]))
        self.net = nn.Sequential(*layers)
        self.net.apply(self.init_weights)
        # Legacy trainable scalar; it enters only the SOAP-phase Ve-sign
        # penalty and is kept so that archived checkpoints load unchanged.
        self.JtFactor = nn.Parameter(torch.tensor(1.0, device=device))

    def init_weights(self, m):
        if isinstance(m, nn.Linear):
            nn.init.xavier_uniform_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)

    def forward(self, X):
        """Physics layer (output transform). Returns 7 normalized columns:
        [Vi, ni, Ez, Te, nn, Vn, Ve].

        Hard constraints (hold at every (z, Qm, R) and every training step):
        inlet anchors on ni and Vi, nn from exact total mass flux, Ve from
        exact current conservation, positivity of ni and Te. The network's
        raw outputs 0-3 are used (Vi, ni, Ez, Te); outputs 4-5 are unused.
        """
        zNorm       = X[:, 0:1]
        raw_outputs = self.net(X)
        _, _, Jt0_vec, niInlet_vec, _, mdot_vec = operating_point(X)

        # Te: positivity only (no inlet or exit anchor); Ez free; Vn fixed
        Te     = torch.exp(raw_outputs[:, 3:4])
        Ez_bar = raw_outputs[:, 2:3]
        Vn     = Vn_bar_init * torch.ones_like(zNorm)

        # ni anchored to its inlet value, positive, confined to ni0*exp(+-8)
        ni = niInlet_vec * torch.exp(8 * torch.tanh(zNorm * raw_outputs[:, 1:2]))
        # Vi enters at the neutral speed; correction >= 0; capped by mdot/ni
        ViMax = mdot_vec / ni
        Vi    = ViInlet + ViMax * torch.tanh(zNorm * (raw_outputs[:, 0:1] ** 2))
        # nn from exact total mass-flux conservation
        nn_var = (mdot_vec - ni * Vi) / Vn_bar_init
        # Ve from exact current conservation
        Ve_bar = Vi - Jt0_vec / (e * ni * n_ref * V_ref)

        return torch.cat((Vi, ni, Ez_bar, Te, nn_var, Vn, Ve_bar), dim=1)


# ==============================================================================
# All residuals normalized by the same scale: n_ref * V_ref / z_ref
# (= characteristic flux divergence scale)
# EEE additionally divided by T_ref to make energy dimensionless
# ==============================================================================

def compute_residuals_tabulated(model, X, collision_ramp=1.0):

    outputs = model(X)
    Vi_bar, ni_bar, Ez_bar, Te_bar, nn_bar, Vn_bar = (
        outputs[:, 0:1], outputs[:, 1:2], outputs[:, 2:3],
        outputs[:, 3:4], outputs[:, 4:5], outputs[:, 5:6])
    Ve_bar = outputs[:, 6:7]   # hard mode: Vi - Jt/(e ni n_ref V_ref), exactly as before

    zNorm = X[:, 0:1]
    z = zMin + (zMax - zMin) * zNorm
    _, _, Jt0_vec, _, _, mdot_vec = operating_point(X)

    dVidz = torch.autograd.grad(Vi_bar, X, torch.ones_like(Vi_bar),
                                create_graph=True)[0][:, 0:1] / (zMax - zMin)
    dnidz = torch.autograd.grad(ni_bar, X, torch.ones_like(ni_bar),
                                create_graph=True)[0][:, 0:1] / (zMax - zMin)
    dTedz  = torch.autograd.grad(Te_bar, X, torch.ones_like(Te_bar),
                                     create_graph=True)[0][:, 0:1] / (zMax - zMin)
    dnndz = torch.autograd.grad(nn_bar, X, torch.ones_like(nn_bar),
                                create_graph=True)[0][:, 0:1] / (zMax - zMin)

    ne_bar  = ni_bar
    #safe_ne = ne_bar + 1e-8

    # --- Physical quantities ---
    Te_eV   = Te_bar * T_ref          # eV
    nn_phys = nn_bar * n_ref          # m^-3
    ni_phys = ni_bar * n_ref          # m^-3

    # --- Tabulated rate coefficients ---
    Kiz      = lookup_Kiz_torch(Te_eV)       # m^3/s
    Km       = lookup_Km_torch(Te_eV)        # m^3/s
    eps_c_eV = lookup_epsc_torch(Te_eV)      # eV

    # --- Magnetic field and collision frequencies ---
    B        = Bmax * torch.exp(-beta_B * ((z / L) - 1.0) ** 2)
    omega_ce = 1.76e7 * B
    alpha_an = 3.5e-3
    nu_en_phys = nn_phys * Km * collision_ramp   # 1/s
    nu_anom    = alpha_an * omega_ce              # 1/s
    nu_m_phys  = nu_en_phys + nu_anom + 1e-9     # 1/s

    # --- Wall loss terms (physical) ---
    delta_r_phys = r2 - r1
    nu_iw_bar, nu_ew_bar, eps_w_bar, sigma = compute_wall_losses(
        Te_bar, ni_bar, delta_r=delta_r_phys, hR=hR)

    # Convert wall frequencies back to physical for source terms
    nu_iw_phys = nu_iw_bar * nu_ref   # 1/s
    nu_ew_phys = nu_ew_bar * nu_ref   # 1/s
    eps_w_eV_field = eps_w_bar * T_ref  # eV  (un-normalize eps_w)

    # --- Normalization scale for flux-divergence equations ---
    # ICE, NCE, IME: divide physical source by (n_ref * V_ref / z_ref)
    flux_scale = n_ref * V_ref / z_ref   # m^-3 s^-1

    #ko_raw   = (1.9435e-5 * Te_eV**3 - 0.0068 * Te_eV**2 + 0.6705 * Te_eV - 1.6329)
    #ko_floor = 1e-6   # floor in the same units as ko_raw (before the 1e-14 scaling)
    #ko_plus  = torch.clamp(ko_raw, min=ko_floor) * 1e-14
    #Sion     = ko_plus * (ne_bar * n_ref) * (nn_bar * n_ref)
    #Stot_bar   = Sion / flux_scale
    
    # --- Ionization source (physical) ---
    Stot_phys  = Kiz * ni_phys * nn_phys * collision_ramp   # m^-3 s^-1
    Stot_bar   = Stot_phys / flux_scale                      # dimensionless

    # --- Wall ion loss source (physical) ---
    Swall_phys = nu_iw_phys * ni_phys                        # m^-3 s^-1
    Swall_bar  = Swall_phys / flux_scale                     # dimensionless

    # --- Electron velocity: taken from the physics layer (column 6) ---
    Jt     = Jt0_vec
    dVedz  = torch.autograd.grad(Ve_bar, X, torch.ones_like(Ve_bar),
                                  create_graph=True)[0][:, 0:1] / (zMax - zMin)

    # --- Hall parameter ---
    OmegaPrime = omega_ce / (nu_m_phys + 0e-9)
    #Ez_bar = OmegaPrime * Ez_bar
    # ==========================================================================
    # ICE: d(ni*Vi)/dz = Stot - Swall  [3] eq.(2), [4] eq.(2)
    # Normalized by n_ref*V_ref/z_ref → all terms O(1e-4 to 1e-3) typically
    # ==========================================================================
    ice = (- ni_bar * dVidz
           - Vi_bar * dnidz
           + Stot_bar
           - Swall_bar)

    # ==========================================================================
    # IME: ni*Vi * dVi/dz = ni*Ez - Swall*(Vi-Vn)  eq.(7), eq.(3)
    # ==========================================================================
    ime = (- Vi_bar * ne_bar * dVidz
           + Ez_bar * ne_bar
           - Stot_bar * (Vi_bar - 0*Vn_bar)
           #- Swall_bar * (Vi_bar - Vn_bar)
           )
    ime = ime

    # ==========================================================================
    # EME: Ez = -OmegaPrime * omega_ce * Ve * (me/mi) * (z_ref/V_ref)
    # eq.(4)-(6)
    # ==========================================================================
    lossEz = (-0*(ne_bar * dTedz + Te_bar * dnidz)
              - Ez_bar * ne_bar
              - OmegaPrime * omega_ce * Ve_bar * ne_bar
              * (m_e / m_i) * (z_ref / V_ref))
              #* z_ref*V_ref*m_e/(e*T_ref))
    lossEz = lossEz

    # ==========================================================================
    # EEE: 0 = -n*Ve*E - n*ng*Kiz*eps_c - n*nu_ew*eps_w  eq.(8), eq.(13)
    #
    # Physical units: [m^-3 s^-1 eV]
    # We normalize by flux_scale * T_ref = n_ref * V_ref / z_ref * T_ref
    # so that each term is O(1) like the other residuals.
    #
    # Term 1 (Joule heating, physical):
    #   P_joule = n * Ve * E = ni_phys * (Ve_bar*V_ref) * (Ez_bar * T_ref/z_ref)
    #           = ni_phys * V_ref * (T_ref/z_ref) * Ve_bar * Ez_bar
    #   Normalized: ne_bar * Ve_bar * Ez_bar  (already dimensionless) ✓
    #
    # Term 2 (collisional+excitation loss, physical):
    #   P_coll = n * ng * Kiz * eps_c  [m^-3 s^-1 eV]
    #   Normalized: Stot_phys * eps_c_eV / (flux_scale * T_ref)
    #             = Stot_bar * (eps_c_eV / T_ref)
    #
    # Term 3 (wall energy loss, physical):
    #   P_wall = n * nu_ew * eps_w  [m^-3 s^-1 eV]
    #   Normalized: ni_phys * nu_ew_phys * eps_w_eV / (flux_scale * T_ref)
    #             = (ni_phys * nu_ew_phys / flux_scale) * (eps_w_eV / T_ref)
    #
    # Note: ni_phys * nu_ew_phys / flux_scale
    #     = (ni_bar * n_ref) * (nu_ew_bar * nu_ref) / (n_ref * V_ref / z_ref)
    #     = ni_bar * nu_ew_bar * (nu_ref * z_ref / V_ref)
    # ==========================================================================

    # Precompute the wall energy normalization factor
    nu_ref_z_over_V = nu_ref * z_ref / V_ref    # dimensionless scale factor

    eee = (- 0*(5 / 2) * ne_bar * Ve_bar * dTedz
           - 0*(5 / 2) * ne_bar * Te_bar * dVedz
           - 0*(5 / 2) * Ve_bar * Te_bar * dnidz
           - ne_bar * Ve_bar * Ez_bar
           #+ Stot_bar * (eps_c_eV / T_ref)
           - Stot_bar * (eps_c_eV / T_ref)
           - ni_bar * nu_ew_bar * (eps_w_eV_field / T_ref) * nu_ref_z_over_V)
    eee = eee

    # ==========================================================================
    # NCE: d(nn*Vn)/dz = -Stot + Swall  eq.(1), [4] eq.(1)
    # ==========================================================================
    nce = (- Vn_bar * dnndz
           - Stot_bar
           + Swall_bar)

    # --- Mass flux residual (identically zero under the hard physics layer) ---
    res_mdot = (ni_bar * Vi_bar + nn_bar * Vn_bar) - mdot_vec

    # --- Current-conservation residual (identically zero under the hard layer) ---
    res_jcons = ni_bar * (Vi_bar - Ve_bar) - Jt / (e * n_ref * V_ref)

    # Residuals are returned RAW (physically normalized by flux_scale only).
    # The old hand-tuned emphasis factors (5e2, 1e2, 3e1, 1e2, 5e2) now live
    # in static_weights as their squares, since mean((c*r)^2) = c^2*mean(r^2).
    # GradNorm learns the weights when USE_GRADNORM=True.
    return ice, ime, lossEz, eee, nce, res_mdot, res_jcons


# ==============================================================================
# Weighted loss helper  (used by both SOAP loop and SSBroyden2 closure)
# ==============================================================================

def pinn_weighted_loss(model, X_train, weights, collision_ramp=1.0):
    res_ice, res_ime, res_ez, res_eee, res_nce, res_mdot, res_jcons = \
        compute_residuals_tabulated(model, X_train,
                                    collision_ramp=collision_ramp)

    loss = (weights['ice']     * torch.mean(res_ice ** 2) +
            weights['ime']     * torch.mean(res_ime ** 2) +
            weights['eme']     * torch.mean(res_ez  ** 2) +
            weights['eee']     * torch.mean(res_eee ** 2) +
            weights['nce']     * torch.mean(res_nce ** 2) +
            weights['mdot']    * torch.mean(res_mdot ** 2)
            )
    return loss


def raw_loss_dict(model, X, collision_ramp=1.0):
    """RAW (unweighted) mean-square residual of every logged equation on X,
    as detached 0-dim tensors keyed by RAW_EQ_NAMES."""
    with torch.no_grad():
        with torch.enable_grad():
            r = compute_residuals_tabulated(model, X, collision_ramp=collision_ramp)
            d = {'ice': torch.mean(r[0] ** 2), 'ime': torch.mean(r[1] ** 2),
                 'eme': torch.mean(r[2] ** 2), 'eee': torch.mean(r[3] ** 2),
                 'nce': torch.mean(r[4] ** 2), 'mdot': torch.mean(r[5] ** 2),
                 'jcons': torch.mean(r[6] ** 2)}
    return {k: v.detach() for k, v in d.items()}


# ==============================================================================
# MAIN – STEP 1: initialise model
# ==============================================================================
print("\n--- STEP 1: INITIALIZATION ---")

layer_sizes = [3] + [48] * 4 + [6]   # 3 inputs, four hidden layers of 48, 6 outputs (4 used)
_LAST_LAYER = 'net.8'                 # key prefix of the output Linear layer
model       = PINN(layer_sizes).to(device)
params      = list(model.parameters())

optimizer_SOAP = pytorch_optimizer.optimizer.soap.SOAP(
    model.parameters(), lr=lr, betas=(.999, .999),
    weight_decay=0e-2, precondition_frequency=1)


def save_train_state(out_path):
    """Optimizer-side state saved next to the weights (GradNorm weights and
    baselines), for record-keeping and warm restarts."""
    ts = {'lr': optimizer_SOAP.param_groups[0]['lr']}
    if USE_GRADNORM:
        ts['gradnorm'] = {
            'weights': {k: v.detach().cpu()
                        for k, v in grad_norm_balancer.weights.items()},
            'initial_losses': dict(grad_norm_balancer.initial_losses),
            'optimizer': grad_norm_balancer.optimizer.state_dict(),
        }
    torch.save(ts, out_path)

# History lists
epoch_history              = []
loss_history_total         = []
loss_history_ice           = []
loss_history_ime           = []
loss_history_eme           = []
loss_history_eee           = []
loss_history_nce           = []
loss_history_mdot          = []
test_loss_history_total    = []
test_loss_history_weighted_ice  = []
test_loss_history_weighted_ime  = []
test_loss_history_weighted_eme  = []
test_loss_history_weighted_eee  = []
test_loss_history_weighted_nce  = []
test_loss_history_weighted_mdot = []
start_epoch = 0

# ==============================================================================
# STEP 2: collocation points
# ==============================================================================

print("\n--- STEP 2: GENERATING POINTS ---")


# --- Training set: scrambled Sobol over the (z, Qm, R) box ---
# Low-discrepancy sampling (advisor feedback): the previous tensor product
# spent 65536 points on only 128 distinct operating points x 512 z-nodes.
# A 3-D Sobol scatter covers the operating space with every point carrying
# a distinct (Qm, R) at identical cost, matches the random-scatter test
# set, and scales gracefully as parametric dimensions are added. Sobol is
# preferred over Hammersley because it is extensible (adaptive resampling
# grows the set), natively available in torch, and optimal at N = 2^m.
sobol   = torch.quasirandom.SobolEngine(dimension=3, scramble=True,
                                        seed=SOBOL_SEED)
X_train = sobol.draw(NUM_TRAIN_POINTS).to(torch.get_default_dtype())
print(f"Training set: {NUM_TRAIN_POINTS} scrambled Sobol points over (z, Qm, R)")
X_train = X_train.to(device).requires_grad_(True)

# --- Residual test set: random triples over the full 3-box ---
X_test = torch.rand(num_test_points, 3, device=device).requires_grad_(True)
print(f"Residual test set: {num_test_points} random (z,Qm,Id) triples")

# --- Held-out benchmark op (Petronio 5 mg/s, 4.5 A) ---
Qm_bench   = 5.0e-6
Id_bench   = 4.5
Qm_bench_n = (Qm_bench - Qm_min) / (Qm_max - Qm_min)
Iion_bench = e * Qm_bench / m_i                  # full single-ionization current [A]
R_bench    = Id_bench / Iion_bench               # = 1.22
Id_bench_n = (R_bench - R_min) / (R_max - R_min)  # 3rd-input coord, now in [0,1]

# --- Confirm the benchmark op is held out of the training set ---
ops_train = torch.unique(X_train[:, 1:3].detach(), dim=0)        # distinct op-points
bench_pt  = torch.tensor([[Qm_bench_n, Id_bench_n]], device=ops_train.device)
d_nn      = torch.cdist(bench_pt, ops_train).min().item()
print(f"distinct training ops: {ops_train.shape[0]} | "
      f"nearest to base case: {d_nn:.4f} (normalized L2)")


# Load model weights if requested

if LoadModel:
    print("\n[LOAD] Attempting to load previous model state...")
    full_model_path = os.path.join(DataDir, ModelToLoad)
    if os.path.exists(full_model_path):
        checkpoint_state  = torch.load(full_model_path, map_location=device)
        current_model_state = model.state_dict()
        checkpoint_outputs  = checkpoint_state[f'{_LAST_LAYER}.weight'].shape[0]
        model_outputs       = current_model_state[f'{_LAST_LAYER}.weight'].shape[0]
        if checkpoint_outputs != model_outputs:
            pretrained_layers = {k: v for k, v in checkpoint_state.items() if _LAST_LAYER not in k}
            current_model_state.update(pretrained_layers)
            num_to_copy = min(checkpoint_outputs, model_outputs)
            with torch.no_grad():
                current_model_state[f'{_LAST_LAYER}.weight'][:num_to_copy, :] = \
                    checkpoint_state[f'{_LAST_LAYER}.weight'][:num_to_copy, :]
                current_model_state[f'{_LAST_LAYER}.bias'][:num_to_copy] = \
                    checkpoint_state[f'{_LAST_LAYER}.bias'][:num_to_copy]
            model.load_state_dict(current_model_state, strict=False)
        else:
            model.load_state_dict(checkpoint_state, strict=False)
        print(f"  -> Loaded weights from: {full_model_path}")
        try:
            filename    = os.path.basename(ModelToLoad)
            start_epoch = int(filename.split('_')[-1].split('.')[0])
            print(f"  -> Resuming from Epoch: {start_epoch}")
        except:
            print("  -> Could not infer epoch from filename.")
    else:
        print(f"  -> ERROR: Model file not found at {full_model_path}")

    full_train_loss_path = os.path.join(DataDir, TrainLossToLoad)
    if os.path.exists(full_train_loss_path):
        _, losses_loaded   = load_losses_from_dat(full_train_loss_path)
        loss_history_total = losses_loaded

# ==============================================================================
# STEP 3 / 4: SOAP training loop
# ==============================================================================

print("\n--- STEP 3/4: SOAP TRAINING ---")
start_t = time.time()
TRAIN_T0 = start_t

# NOTE: task set trimmed to the four INDEPENDENT equations.
# - 'mdot' is zero by construction (~1e-37 in every log): it carries no
#   gradient signal, so its grad norm and loss ratio only distort
#   GradNorm's averages.
# - 'nce' is algebraically identical to 'ice' under the output transform
#   nn = (mdot - ni*Vi)/Vn with constant Vn: -Vn*dnn/dz = d(ni*Vi)/dz.
#   (Confirmed empirically: ICE and NCE print bit-identical losses at every
#   checkpoint.) Balancing it would double-count one task.
# - 'jcons' (current conservation) is, like 'mdot', zero by construction
#   under the hard physics layer and carries no gradient signal.
# Both nce and mdot still appear in the total loss with tied weights
# (nce follows ice; mdot stays at 1.0).
active_losses = ['ice', 'ime', 'eme', 'eee']

if USE_GRADNORM:
    # Warm-up is relative to the starting epoch so that initialization
    # transients are never cached as the L(0) baselines.
    gn_warmup = start_epoch + GRADNORM_WARMUP_EPOCHS
    grad_norm_balancer = GradNormBalancer(model, active_losses,
                                          alpha=GRADNORM_ALPHA,
                                          learning_rate=GRADNORM_LR,
                                          warmup=gn_warmup)
    print(f"--- GradNorm INITIALIZED (LR={GRADNORM_LR}, "
          f"warmup until epoch {gn_warmup}) ---")
else:
    grad_norm_balancer = None

# Legacy emphasis factors as static weights: c^2 of the old residual
# prefactors (5e2, 1e2, 3e1, 1e2, 5e2, 1). With USE_GRADNORM=False this
# reproduces the previous training numerics exactly.
static_weights = {
    'ice':  torch.tensor(2.5e5, device=device),   # (5e2)^2
    'ime':  torch.tensor(1.0e4, device=device),   # (1e2)^2
    'eme':  torch.tensor(9.0e2, device=device),   # (3e1)^2
    'eee':  torch.tensor(1.0e4, device=device),   # (1e2)^2
    'nce':  torch.tensor(2.5e5, device=device),   # (5e2)^2
    'mdot': torch.tensor(1.0,   device=device),
}

model.train()


for epoch in range(start_epoch, epochsSOAP):
    optimizer_SOAP.zero_grad()

    collision_ramp = 1.0   # collision terms at full strength throughout
    res_ice, res_ime, res_ez, res_eee, res_nce, res_mdot, res_jcons = \
        compute_residuals_tabulated(model, X_train)

    outputs = model(X_train)
    Ez_bar  = outputs[:, 2:3]
    ni_bar  = outputs[:, 1:2]
    Vi_bar  = outputs[:, 0:1]

    # Two auxiliary penalties act in the SOAP phase only (they are absent
    # from pinn_weighted_loss, i.e. from the SSBroyden phase): a floor on
    # ni at 35 % of the normalized total particle flux, and a penalty on a
    # positive (anode-directed) electron velocity.
    _, _, Jt0_vec_tr, _, _, mdot_bar_vec_tr = operating_point(X_train)

    loss_density_penalty = torch.mean(
        torch.relu(0.35 * mdot_bar_vec_tr - ni_bar) ** 2)

    Jt_current     = Jt0_vec_tr * model.JtFactor
    Ve_bar_current = Vi_bar - Jt_current / (e * ni_bar * n_ref * V_ref)
    loss_Ve_pos    = torch.mean(torch.relu(Ve_bar_current) ** 2)

    loss_ice     = torch.mean(res_ice ** 2)
    loss_ime     = torch.mean(res_ime ** 2)
    loss_eme     = torch.mean(res_ez  ** 2)
    loss_eee     = torch.mean(res_eee ** 2)
    loss_nce     = torch.mean(res_nce ** 2)
    loss_mdot    = torch.mean(res_mdot ** 2)
    loss_jcons   = torch.mean(res_jcons ** 2)

    losses_dict = {
        'ice': loss_ice, 'ime': loss_ime, 'eme': loss_eme,
        'eee': loss_eee, 'nce': loss_nce, 'mdot': loss_mdot,
        'jcons': loss_jcons,
        'loss_density': loss_density_penalty,
        'loss_Ve_pos': loss_Ve_pos,
    }

    # Chen et al. (2018) Algorithm 1 ordering: the standard gradient
    # grad_theta L(t) is computed with the CURRENT weights w(t); the weight
    # update (and its trailing renormalization) happens afterwards.
    if USE_GRADNORM:
        weights = {k: v.detach().clone()
                   for k, v in grad_norm_balancer.weights.items()}
        # Tied weights for the degenerate terms excluded from balancing:
        # nce is algebraically ice (see active_losses note); mdot is zero
        # by construction so its weight is irrelevant.
        weights['nce']  = weights['ice']
        weights['mdot'] = torch.tensor(1.0, device=device)
    else:
        weights = static_weights

    total_loss = (weights['ice']     * losses_dict['ice'] +
                  weights['ime']     * losses_dict['ime'] +
                  weights['eme']     * losses_dict['eme'] +
                  weights['eee']     * losses_dict['eee'] +
                  weights['mdot']    * losses_dict['mdot'] +
                  weights['nce']     * losses_dict['nce'] +
                  100 * losses_dict['loss_density'] +
                  100 * losses_dict['loss_Ve_pos'])

    # retain_graph only when GradNorm must re-differentiate the same graph
    total_loss.backward(retain_graph=USE_GRADNORM)
    if USE_GRADNORM:
        grad_norm_balancer.step(losses_dict, global_step=epoch)
    optimizer_SOAP.step()

    if epoch == 0 or (epoch + 1) % 100 == 0:
        current_epoch = epoch + 1
        model.eval()
        raw_t = raw_loss_dict(model, X_test)
        loss_ice_t, loss_ime_t, loss_eme_t = raw_t['ice'], raw_t['ime'], raw_t['eme']
        loss_eee_t, loss_nce_t, loss_mdot_t = raw_t['eee'], raw_t['nce'], raw_t['mdot']

        w_ice_t  = weights['ice'].item()  * loss_ice_t.item()
        w_ime_t  = weights['ime'].item()  * loss_ime_t.item()
        w_eme_t  = weights['eme'].item()  * loss_eme_t.item()
        w_eee_t  = weights['eee'].item()  * loss_eee_t.item()
        w_nce_t  = weights['nce'].item()  * loss_nce_t.item()
        w_mdot_t = weights['mdot'].item() * loss_mdot_t.item()
        total_loss_test = w_ice_t + w_ime_t + w_eme_t + w_eee_t + w_nce_t + w_mdot_t

        test_loss_history_total.append(total_loss_test)
        test_loss_history_weighted_ice.append(w_ice_t)
        test_loss_history_weighted_ime.append(w_ime_t)
        test_loss_history_weighted_eme.append(w_eme_t)
        test_loss_history_weighted_eee.append(w_eee_t)
        test_loss_history_weighted_nce.append(w_nce_t)
        test_loss_history_weighted_mdot.append(w_mdot_t)

        epoch_history.append(current_epoch)
        loss_history_total.append(total_loss.item())
        loss_history_ice.append(loss_ice.item())
        loss_history_ime.append(loss_ime.item())
        loss_history_eme.append(loss_eme.item())
        loss_history_eee.append(loss_eee.item())
        loss_history_nce.append(loss_nce.item())
        loss_history_mdot.append(loss_mdot.item())

        # Raw (unweighted) per-equation logging: loss_* and loss_*_t are
        # already mean(r^2) of RAW residuals, so this costs nothing extra.
        log_raw_losses(current_epoch, phase=0,
                       train_vals={k: float(losses_dict[k]) for k in RAW_EQ_NAMES},
                       test_vals ={k: float(raw_t[k])       for k in RAW_EQ_NAMES})

        print(f"Epoch {epoch+1}/{epochsSOAP} | "
              f"Train: {total_loss.item():.4e} | Test: {total_loss_test:.4e} | "
              f"ICE: {w_ice_t:.2e} IME: {w_ime_t:.2e} EME: {w_eme_t:.2e} "
              f"EEE: {w_eee_t:.2e} NCE: {w_nce_t:.2e} mdot: {w_mdot_t:.2e}",
              flush=True)
        if USE_GRADNORM:
            w_str  = " ".join(f"{k}:{v.item():.3f}"
                              for k, v in grad_norm_balancer.weights.items())
            l0_str = " ".join(f"{k}:{v:.2e}"
                              for k, v in grad_norm_balancer.initial_losses.items()) \
                     if grad_norm_balancer.initial_losses else "(not cached yet)"
            print(f"   [GradNorm] w: {w_str} | L0: {l0_str}", flush=True)
        model.train()

    if (epoch + 1) % SaveEveryEpoch == 0:
        print(f"[SAVE] Checkpoint at epoch {epoch+1}...")
        torch.save(model.state_dict(),
                   f"{model_path}pinn_weights_epoch_{epoch+1:05d}.pth")
        torch.save({'X_train': X_train}, f"{model_path}train_points.pth")
        save_train_state(f"{model_path}train_state.pth")
        steps_train = range(1, len(loss_history_total) + 1)
        steps_test_ = range(1, len(test_loss_history_total) + 1)
        save_losses_to_dat(steps_train, loss_history_total,
                           f"{model_path}training_losses.dat")
        save_losses_to_dat(steps_test_, test_loss_history_total,
                           f"{model_path}test_losses.dat")
        save_raw_losses_dat(f"{model_path}raw_losses.dat")

t_soap_end = time.time()
soap_wall_s = t_soap_end - start_t

# Final SOAP save (training runs only: in eval mode the histories are empty
# and writing them here would clobber the archived run's .dat record)
if IF_TRAIN:
    torch.save(model.state_dict(), f"{model_path}pinn_weights_epoch_{epochsSOAP:05d}.pth")
    with open(f"{model_path}ssb_checkpoints.csv", 'w') as _f:
        _f.write("ssb_iter,wall_total_s,wall_ssb_s,train_weighted_loss,test_raw_sum_core4\n")
        _f.write(f"0,{soap_wall_s:.2f},0.00,nan,nan\n")
    torch.save({'X_train': X_train}, f"{model_path}train_points.pth")
    save_train_state(f"{model_path}train_state.pth")
    steps_train = range(1, len(loss_history_total) + 1)
    steps_test_ = range(1, len(test_loss_history_total) + 1)
    save_losses_to_dat(steps_train, loss_history_total, f"{model_path}training_losses.dat")
    save_losses_to_dat(steps_test_, test_loss_history_total, f"{model_path}test_losses.dat")
    save_raw_losses_dat(f"{model_path}raw_losses.dat")
    print("\nSOAP training finished.")
else:
    print("\n[EVAL] Skipping SOAP checkpoint writes (IF_TRAIN = False).")

if USE_GRADNORM:
    final_weights = {k: v.detach() for k, v in grad_norm_balancer.weights.items()}
    final_weights['nce']  = final_weights['ice']      # tied (same equation)
    final_weights['mdot'] = torch.tensor(1.0, device=device)
else:
    final_weights = static_weights
print("[phase-2] weights handed to the quasi-Newton phase (held fixed):")
for name, weight in final_weights.items():
    print(f"  - {name}: {weight.item():.4f}")

soap_final_step = len(loss_history_total)

# ==============================================================================
# STEP 5: SSBroyden2 fine-tuning  (replaces Scipy L-BFGS-B)
# ==============================================================================

if USE_SSBROYDEN:
    X_SSB = X_train   # same fixed collocation set as the SOAP phase
    print(f"\nStarting SSBroyden2 ({len(X_SSB)} points, {epochsSSB} max iterations)...")
    t_ssb_start = time.time()
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()

    SSB_HPARAMS = dict(lr=0.1, gtol=1e-12, line_search="strong_wolfe",
                       c1=1e-4, c2=0.9, wolfe_maxiter=20, zoom_maxiter=40,
                       amax=10)
    opt_ssb = SSBroyden2(model.parameters(), dtype=torch.float64,
                         device=device, **SSB_HPARAMS)

    model.train()
    ssb_step_counter = [0]
    last_good_state  = copy.deepcopy(model.state_dict())   # NaN circuit breaker

    for ssb_step in range(epochsSSB):

        def closure():
            opt_ssb.zero_grad(set_to_none=True)
            loss = pinn_weighted_loss(model, X_SSB, final_weights)
            loss.backward()
            return loss

        fk = opt_ssb.step(closure)

        # Circuit breaker: a non-finite loss means the optimizer state is
        # poisoned; every further iteration is wasted. Restore the last
        # finite model and end the phase so plots/checkpoints stay usable.
        fk_val = fk.item() if torch.is_tensor(fk) else float(fk)
        if not np.isfinite(fk_val):
            print(f"*** SSB Iter {ssb_step}: NON-FINITE loss ({fk_val}). "
                  f"Restoring last finite state (iter {max(ssb_step-1, 0)}) "
                  f"and ending the SSBroyden phase early. ***", flush=True)
            model.load_state_dict(last_good_state)
            break
        last_good_state = copy.deepcopy(model.state_dict())

        if ssb_step % 100 == 0 or ssb_step == 0:
            # Test loss
            raw_t2 = raw_loss_dict(model, X_test)
            raw_ice_t2  = raw_t2['ice'].item()
            raw_ime_t2  = raw_t2['ime'].item()
            raw_eme_t2  = raw_t2['eme'].item()
            raw_eee_t2  = raw_t2['eee'].item()
            raw_nce_t2  = raw_t2['nce'].item()
            raw_mdot_t2 = raw_t2['mdot'].item()

            w_ice_t2  = final_weights['ice'].item()  * raw_ice_t2
            w_ime_t2  = final_weights['ime'].item()  * raw_ime_t2
            w_eme_t2  = final_weights['eme'].item()  * raw_eme_t2
            w_eee_t2  = final_weights['eee'].item()  * raw_eee_t2
            w_nce_t2  = final_weights['nce'].item()  * raw_nce_t2
            w_mdot_t2 = final_weights['mdot'].item() * raw_mdot_t2
            test_total = w_ice_t2 + w_ime_t2 + w_eme_t2 + w_eee_t2 + w_nce_t2 + w_mdot_t2

            # Raw train on the SSB collocation set (one extra residual
            # evaluation per 100 iters; cheap next to the 200k-point test set)
            raw_tr = raw_loss_dict(model, X_SSB)
            log_raw_losses(ssb_step, phase=1,
                           train_vals={k: float(raw_tr[k]) for k in RAW_EQ_NAMES},
                           test_vals ={k: float(raw_t2[k]) for k in RAW_EQ_NAMES})

            loss_history_total.append(fk.item() if torch.is_tensor(fk) else float(fk))
            test_loss_history_total.append(test_total)
            test_loss_history_weighted_ice.append(w_ice_t2)
            test_loss_history_weighted_ime.append(w_ime_t2)
            test_loss_history_weighted_eme.append(w_eme_t2)
            test_loss_history_weighted_eee.append(w_eee_t2)
            test_loss_history_weighted_nce.append(w_nce_t2)
            test_loss_history_weighted_mdot.append(w_mdot_t2)

            if IF_TRAIN and ssb_step in SSB_CHECKPOINT_ITERS:
                torch.save(model.state_dict(),
                           f"{model_path}pinn_weights_ssb_{ssb_step:05d}.pth")
                with open(f"{model_path}ssb_checkpoints.csv", 'a') as _f:
                    if _f.tell() == 0:
                        _f.write("ssb_iter,wall_total_s,wall_ssb_s,train_weighted_loss,test_raw_sum_core4\n")
                    _f.write(f"{ssb_step},{time.time()-start_t:.2f},{time.time()-t_ssb_start:.2f},"
                             f"{fk.item() if torch.is_tensor(fk) else fk:.6e},"
                             f"{raw_ice_t2+raw_ime_t2+raw_eme_t2+raw_eee_t2:.6e}\n")
                print(f"   [ckpt] saved pinn_weights_ssb_{ssb_step:05d}.pth at "
                      f"{time.time()-start_t:.1f} s total")
            print(f"SSB Iter {ssb_step} | "
                  f"Train: {fk.item() if torch.is_tensor(fk) else fk:.4e} | "
                  f"Test: {test_total:.4e} | "
                  f"ICE: {w_ice_t2:.2e} IME: {w_ime_t2:.2e} "
                  f"EME: {w_eme_t2:.2e} EEE: {w_eee_t2:.2e} "
                  f"NCE: {w_nce_t2:.2e} mdot: {w_mdot_t2:.2e}",
                  flush=True)
    torch.save(model.state_dict(), f"{model_path}pinn_weights_final_ssbroyden.pth")
    ssb_wall_s = time.time() - t_ssb_start
    if IF_TRAIN:
        with open(f"{model_path}ssb_checkpoints.csv", 'a') as _f:
            if _f.tell() == 0:
                _f.write("ssb_iter,wall_total_s,wall_ssb_s,train_weighted_loss,test_raw_sum_core4\n")
            _f.write(f"{epochsSSB},{time.time()-start_t:.2f},{ssb_wall_s:.2f},nan,nan\n")
    ssb_peak_gpu_GB = (torch.cuda.max_memory_allocated() / 1e9
                       if torch.cuda.is_available() else float('nan'))
    print(f"SSBroyden2 phase complete: {ssb_wall_s:.1f} s, "
          f"peak GPU memory during phase 2 = {ssb_peak_gpu_GB:.2f} GB")
else:
    ssb_wall_s, ssb_peak_gpu_GB = 0.0, float('nan')
    print("\nSkipping phase-2 (quasi-Newton) optimizer.")

end_t = time.time()
total_wall_s = end_t - start_t
print(f"\nTotal training time: {total_wall_s:.2f} s "
      f"(SOAP {soap_wall_s:.1f} s + phase-2 {ssb_wall_s:.1f} s)")
JtFactor_predict = model.JtFactor.item()
print(f"Predicted JtFactor = {JtFactor_predict}")

# ==============================================================================
# POST-PROCESSING (figures, benchmark statistics, constant-voltage sweep,
# operating-envelope map, extrapolation test, cross-validation against the
# conventional solver). Lives in hallpinn_postprocess.py and runs in this
# script's namespace, so it sees the trained model and every constant above.
# ==============================================================================
RUN_POSTPROCESS = True
_post = os.path.join(SCRIPT_DIR, 'hallpinn_postprocess.py')
if RUN_POSTPROCESS and os.path.exists(_post):
    import runpy
    runpy.run_path(_post, init_globals=globals(), run_name='__postprocess__')
else:
    print("Post-processing skipped (hallpinn_postprocess.py not found or disabled).")
